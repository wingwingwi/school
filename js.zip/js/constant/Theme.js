const Theme = {
    //颜色
   color_red:'#f00',
   color_white:'#fff',
   color_grey:'#999',
   color_black:'#000',
   color_black2:'#222',
   color_black3:'#333',
   color_black4:'#444',
   color_black5:'#555',
   color_black6:'#666', 
   //字体大小
   size_10:10,
   size_11:11,
   size_12:12,
   size_13:13,
   size_14:14,
   size_15:15,
   size_16:16,
   size_17:17,
   size_18:18,
   size_19:19,
   size_20:20,
}

export default Theme;//导出，用于其他地方调用