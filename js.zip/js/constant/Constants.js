module.exports = {
    _token: {t: '', isPerfect: 0,bySource:0}
}